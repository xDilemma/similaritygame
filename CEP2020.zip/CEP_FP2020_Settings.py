import pygame as pg
import sys
from os import path
import random

pg.init()

#Colours
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
DARKGREY = (40, 40, 40)
LIGHTGREY = (100, 100, 100)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
BLUE = (0,0,255)
YELLOW = (255, 255, 0)
BROWN = (106, 55, 5)
mb_colour = (204,153,255)
mb_colour2 = (178,102,255)

#Fonts
arial20 = pg.font.SysFont('Arial', 20, True, False)
arial25 = pg.font.SysFont('Arial', 25, True, False)
arial55 = pg.font.SysFont('Arial', 55, True, False)
arial35 = pg.font.SysFont('Arial', 35, True, False)
arial120 = pg.font.SysFont('Arial', 120, True, False)

#Game Settings
clock = pg.time.Clock()
WIDTH =  1000
HEIGHT = 800
MIDWIDTH = 500
MIDHEIGHT = 400
FPS = 120
screen = pg.display.set_mode((WIDTH,HEIGHT))

#Files
game_folder = path.dirname(__file__)
assets_folder = path.join(game_folder, 'assets')
felines_folder = path.join(game_folder, 'felines')
water_folder = path.join(game_folder, 'water')
ballsports_folder = path.join(game_folder, 'ballsports')
esports_folder = path.join(game_folder, 'esports')
nature_folder = path.join(game_folder, 'nature')
martialarts_folder = path.join(game_folder, 'martialarts')
wrestling_folder = path.join(game_folder, 'wrestling')
light_folder = path.join(game_folder, 'light')
music_folder = path.join(game_folder, 'music')
celebrities_folder = path.join(game_folder, 'celebrities')
cartoon_folder = path.join(game_folder,'cartoon')

#Text Questions
compliments = ["Hey, you look nice today!","Well done!","I appreciate you.","Your the best!","Damn you're good!"]
disgust = ["Ew what...","What is this smell?","It's rotten!","Why is it so dirty?","Excuse me?"]
annoyed = ["Shut up please.","Get out la!","What are you doing?","What's wrong with you?","Don't piss me off."]
excited = ["Yes, let's go!","Nice one la","I won leh!","This is damn fun!","Oi, faster la oi! faster!"]
formal = ["Would you please help me with this?","Oh, thank you so much for your help.","Excuse me, can I seek a favour from you?","No problem, I will get  it done.","How can I help you?"]
depressed = ["Leave me alone","This is not fun","Why is this so boring?","Man, life sucks","I don't wanna do anything"]
commands = ["Oi come here now!","Go face the wall!","You better get this done kid.","Knock it down","Limpeh better stand up and shut up."]
requests = ["Help me please.","Do this for me, thanks.","Can I trouble you to do this?","Boy, come here and help Mommy.","May I go now?"]
rhetoric = ["Isn't it obvious?","Samsung is much better, isn't it?","Don't you wanna do this?","Who cares, right?","Why me?"]

#Convenient functions
def text_centering(text,x,y,type):
    textrect = text.get_rect()
    if type == "both":
        textrect.centerx = x//2
        textrect.centery = y//2
    elif type == "x":
        textrect.centerx = x//2
        textrect.y = y
    elif type == "y":
        textrect.x = x
        textrect.centery = y//2
    else:
        pass
    return textrect

def scaling_images(x,y,img_name,filename,angle):
    image = pg.transform.rotate(pg.image.load(path.join(filename, img_name)).convert_alpha(),angle)
    image = pg.transform.scale(image, (x, y))
    return image

def question_images(filename):
    image1 = scaling_images(250,215,str(1)+".jpg",filename,0)
    image2 = scaling_images(250,215,str(2)+".jpg",filename,0)
    image3 = scaling_images(250,215,str(3)+".jpg",filename,0)
    image4 = scaling_images(250,215,str(4)+".jpg",filename,0)
    image5 = scaling_images(250,215,str(5)+".jpg",filename,0)
    image6 = scaling_images(250,215,str(6)+".jpg",filename,0)
    image7 = scaling_images(250,215,str(7)+".jpg",filename,0)
    image8 = scaling_images(250,215,str(8)+".jpg",filename,0)
    lst =[image1,image2,image3,image4,image5,image6,image7,image8]
    flst = []
    hlst1 = []
    hlst2 = []
    for i in range(3):
        a = random.choice(lst)
        hlst1.append([a,[30+i*340,210]])
        lst.remove(a)
    for i in range(2):
        b = random.choice(lst)
        hlst2.append([b,[195+i*375,440]])
        lst.remove(b)
    for i in hlst1:
        flst.append(i)
    for i in hlst2:
        flst.append(i)
    return flst

def question_texts(topic):
    lst = []
    if topic == "compliments":
        for i in range(5):
            surface = pg.Surface((500,50))
            key = arial25.render(str(i+1) + ". " +compliments[i],True,WHITE)
            surface.blit(key,text_centering(key,10,50,"y"))
            lst.append([surface,[220,210+i*100]])
    if topic == "disgust":
        for i in range(5):
            surface = pg.Surface((500,50))
            key = arial25.render(str(i+1) + ". " +disgust[i],True,WHITE)
            surface.blit(key,text_centering(key,10,50,"y"))
            lst.append([surface,[220,210+i*100]])
    if topic == "annoyed":
        for i in range(5):
            surface = pg.Surface((500,50))
            key = arial25.render(str(i+1) + ". " +annoyed[i],True,WHITE)
            surface.blit(key,text_centering(key,10,50,"y"))
            lst.append([surface,[220,210+i*100]])
    if topic == "excited":
        for i in range(5):
            surface = pg.Surface((500,50))
            key = arial25.render(str(i+1) + ". " +excited[i],True,WHITE)
            surface.blit(key,text_centering(key,10,50,"y"))
            lst.append([surface,[220,210+i*100]])
    if topic == "formal":
        for i in range(5):
            surface = pg.Surface((500,50))
            key = arial25.render(str(i+1) + ". " +formal[i],True,WHITE)
            surface.blit(key,text_centering(key,10,50,"y"))
            lst.append([surface,[220,210+i*100]])
    if topic == "commands":
        for i in range(5):
            surface = pg.Surface((500,50))
            key = arial25.render(str(i+1) + ". " +commands[i],True,WHITE)
            surface.blit(key,text_centering(key,10,50,"y"))
            lst.append([surface,[220,210+i*100]])
    if topic == "requests":
        for i in range(5):
            surface = pg.Surface((500,50))
            key = arial25.render(str(i+1) + ". " +requests[i],True,WHITE)
            surface.blit(key,text_centering(key,10,50,"y"))
            lst.append([surface,[220,210+i*100]])
    if topic == "rhetoric":
        for i in range(5):
            surface = pg.Surface((500,50))
            key = arial25.render(str(i+1) + ". " +rhetoric[i],True,WHITE)
            surface.blit(key,text_centering(key,10,50,"y"))
            lst.append([surface,[220,210+i*100]])
    if topic == "depressed":
        for i in range(5):
            surface = pg.Surface((500,50))
            key = arial25.render(str(i+1) + ". " +depressed[i],True,WHITE)
            surface.blit(key,text_centering(key,10,50,"y"))
            lst.append([surface,[220,210+i*100]])
    return lst

def question_info(topic):
    lst = []
    if topic == "felines":
        lst = question_images(felines_folder)
    elif topic == "light":
        lst = question_images(light_folder)
    elif topic == "celebrities":
        lst = question_images(celebrities_folder)
    elif topic == "wrestling":
        lst = question_images(wrestling_folder)
    elif topic == "martialarts":
        lst = question_images(martialarts_folder)
    elif topic == "water":
        lst = question_images(water_folder)
    elif topic == "ballsports":
        lst = question_images(ballsports_folder)
    elif topic == "esports":
        lst = question_images(esports_folder)
    elif topic == "music":
        lst = question_images(music_folder)
    elif topic == "nature":
        lst = question_images(nature_folder)
    elif topic == "cartoon":
        lst = question_images(cartoon_folder)
    else:
        lst = question_texts(topic)
    return lst
#Images
tick_img = scaling_images(70,80,"tick.png",assets_folder,-5) #https://www.google.com/url?sa=i&url=http%3A%2F%2Fpluspng.com%2Fpng-wrong-cross-2223.html&psig=AOvVaw09cir7GpibrpssCsWQsEKS&ust=1584545174935000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCIjdh_nooegCFQAAAAAdAAAAABAD
cross_img = scaling_images(70,80,"cross.png",assets_folder,-5) #https://www.google.com/url?sa=i&url=https%3A%2F%2Fya-webdesign.com%2Fimage%2Fgreen-tick-png%2F670310.html&psig=AOvVaw3dmHrOyCi3ohjA1_n1iMMy&ust=1584545830000000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCNjF46zroegCFQAAAAAdAAAAABAq
hint_img = scaling_images(50,50,"hint.png",assets_folder,5)#https://www.google.com/url?sa=i&url=http%3A%2F%2Fwww.pngmart.com%2Fimage%2F5220&psig=AOvVaw0wV7FLmZTkqkgeKX6zKXgf&ust=1585659467328000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCJDcxfyfwugCFQAAAAAdAAAAABAT
gbackground_img = scaling_images(WIDTH,HEIGHT,"black-background-hd.jpg",assets_folder,0)#https://wallpapermemory.com/54030
dog1_img = scaling_images(200,400,"dog.jpg",assets_folder,-8)#https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.goodhousekeeping.com%2Flife%2Fpets%2Fadvice%2Fg1921%2Flarge-dog-breeds%2F&psig=AOvVaw2D8QysPJIDZ4oKq6-OAZfH&ust=1585831048247000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCJiX_fKfx-gCFQAAAAAdAAAAABAD
dog2_img = scaling_images(190,320,"dog2.jpg",assets_folder,5)#https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.hiclipart.com%2Ffree-transparent-background-png-clipart-dysmn&psig=AOvVaw2q3IuOdTCuzXxs2xefC8VU&ust=1585831373026000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCNjDw7Ggx-gCFQAAAAAdAAAAABAD
dog3_img = scaling_images(200,300,"dog3.jpg",assets_folder,5)#https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.dw.com%2Fen%2Fpuppy-dog-eyes-developed-to-manipulate-humans%2Fa-49241736&psig=AOvVaw3bkPOQLUMBDPVZTfGphvR0&ust=1585831369526000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCLiwx9igx-gCFQAAAAAdAAAAABAD
question_mark_img = scaling_images(350,500,"questionmark.png",assets_folder,0)#https://www.google.com/url?sa=i&url=http%3A%2F%2Fwww.pngmart.com%2Fimage%2F135060&psig=AOvVaw0lR-TdBhfrIBFteTEdb6OA&ust=1585921743555000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCKjnuovxyegCFQAAAAAdAAAAABAa

#Game Variables
full_question_dict = {"felines":["What is common among the pictures? (1 word)",["felines","cats"],"Animal family"],"light":["What do these pictures have in common? (1 word)",["light"],"_i_gh_"],"celebrities":["What do these people have in common? (1 word)",["celebrities","celebrity"],"Famous"],"esports":["What common thing does these pictures show? (1 word)",["esports","gaming"],"Type of sport"],"ballsports":["What is common between these sports? (2 words)",["ball sports","ball sport"],"Equipment"],"wrestling":["What do these pictures show? (1 word)",["wrestling"],"WWE"],"martialarts":["What do these pictures have in common? (1 or 2 words)",["martial arts","fighting","martial art"],"different forms of ___"],"water":["What is common in these pictures? (1 word)",["water"],"made of ___"],"nature":["What is the common theme shown by these pictures? (1 word)",["nature","environment"],"mother ___"],"music":["What do these pictures have in common?",["music"],"form of art"],"cartoon":["What do these characters have in common? (1 word)",["cartoon","animation"],"_____ Network"],"compliments":["What kind of sentences are these? (1 word)",["compliments","praises"],"Positive messages"],"disgust":["What kind of tone do these sentences have? (1 word)",["disgust","disgusted"],"Synonym of distaste"],"annoyed":["What kind of tone do these sentences have? (1 word)",["annoyed","frustrated","irritated","annoyance","frustration"],"Synonym for impatient"],"formal":["What kind of tone do these sentences have? (1 word)",["formal","polite"],"Polite"],"commands":["What kind of sentences are these? (1 word)",["Commands","orders","command","order"],"Authoritative"],"depressed":["What kind of tone do these sentences have? (1 word)",["depressed","depression"],"Synonym for downcast"],"requests":["What kind of sentences are these? (1 word)",["requests","request"],"Asking for something"],"rhetoric":["What kind of sentences are these? (2 words)",["rhetorical questions","rhetorical question"],"Obvious answers"],"excited":["What kind of tone do these sentences have? (1 word)",["excited","excitement"],"Synonym for thrilled"]} 
paused = False
elapsed_time = 0
elapsed_time_lst = []
full_elapsed_time_lst = []
p_time = 0
add = 0
add_score = 0
hint_left = 0
hint_minus = 0
